

module.exports = function(LessonGetter) {

	

	LessonGetter.get = hent;

}