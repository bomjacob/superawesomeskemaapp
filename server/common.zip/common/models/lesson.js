

module.exports = function(Lesson) {

};